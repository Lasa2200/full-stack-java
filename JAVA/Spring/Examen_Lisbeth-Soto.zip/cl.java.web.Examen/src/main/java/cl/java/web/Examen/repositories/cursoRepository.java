//package cl.java.web.Examen.repositories;
//import org.springframework.data.repository.CrudRepository;
//import org.springframework.stereotype.Repository;
//import cl.java.web.Examen.models.Cursos;
//
//@Repository
//public interface cursoRepository  extends CrudRepository<Cursos, Long>{
//
//}
