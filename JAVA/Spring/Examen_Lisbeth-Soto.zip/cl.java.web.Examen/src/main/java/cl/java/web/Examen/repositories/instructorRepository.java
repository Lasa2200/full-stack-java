//package cl.java.web.Examen.repositories;
//
//import org.springframework.data.repository.CrudRepository;
//import org.springframework.security.core.userdetails.User;
//
//public interface instructorRepository extends CrudRepository<User, Long>{
//	
//} 
