package cl.java.web.CertificacionSence;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CertificacionSenceApplicationTests {

	@Test
	void contextLoads() {
	}

}
