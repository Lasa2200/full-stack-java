package cl.java.web.CertificacionSence.Consultas;

//e)	El gerente general de la compañía desea conocer el valor total del inventario 
//(inventario valorizado) existente en cada almacén. Para llevar a cabo dicho requerimiento,
//confeccione un reporte que acumule el costo de cada producto multiplicado por la cantidad,
//agrupado por almacén y ordenado de forma descendente por dicho valor.
//El reporte debe tener la siguiente forma:


public @interface E_sql {

}
