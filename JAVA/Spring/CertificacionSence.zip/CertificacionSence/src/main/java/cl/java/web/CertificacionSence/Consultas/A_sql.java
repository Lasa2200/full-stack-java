package cl.java.web.CertificacionSence.Consultas;


//a)	El Product Manager, solicitó un listado de todos los productos de la categoría
//‘Storage’, con su nombre y precio, ordenados alfabéticamente por nombre. 
//El reporte debe tener la siguiente forma:



//select product_id, product_name, list_price;
//from products
//Order by product_name desc


public @interface A_sql {

}
