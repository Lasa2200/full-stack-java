package cl.java.web.CertificacionSence.Consultas;


//d)	El área de ventas que cubre la ciudad de San Francisco,
//requiere un listado actualizado con los inventarios de los productos ‘Intel’ 
//que existen en el almacén ‘San Francisco’. Genere un reporte con la cantidad 
//de inventario de productos ‘Intel’ existentes en dicho almacén, 
//ordenado alfabéticamente por producto. El reporte debe tener la siguiente forma:
	
public @interface D_sql {

}
