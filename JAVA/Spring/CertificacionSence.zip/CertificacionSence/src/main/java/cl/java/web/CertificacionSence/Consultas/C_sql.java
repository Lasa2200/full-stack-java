package cl.java.web.CertificacionSence.Consultas;


//c)	Un cliente a nivel mundial requiere saber qué bodegas de almacenamiento 
//(warehouses) tiene la compañía y dónde se encuentran ubicadas.
//Para eso, le han solicitado un listado de todos los países 
//junto a sus respectivas ubicaciones de almacenes, ordenado alfabéticamente por país.
//El reporte debe tener la siguiente forma:

public @interface C_sql {

}
