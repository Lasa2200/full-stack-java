package cl.java.web.CertificacionSence.Consultas;


////b)	El Product Manager, para realizar una gestión por categoría, 
//requiere saber cuántos productos hay en cada categoría.
//Se le solicita un reporte con la cantidad de productos de cada categoría,
//ordenado de mayor a menor cantidad. El reporte debe tener la siguiente forma:

public @interface B_sql {

}
